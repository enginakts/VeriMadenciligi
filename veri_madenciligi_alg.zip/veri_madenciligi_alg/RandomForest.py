#  Random Forest (Rassal Orman)
# Ne için kullanılır?: Karar Ağacının genişletilmiş ve daha güçlü bir versiyonudur. Birden fazla Karar Ağacı modelini birleştirerek (ensemble) daha doğru tahminler yapar. Aynı veri seti üzerinde birçok farklı ağaç eğitilir ve bu ağaçların çoğunluğuna göre sonuç tahmin edilir.
# Avantajları: Genel olarak çok güçlü bir sınıflandırıcıdır ve overfitting'e karşı daha dirençlidir.
# Dezavantajları: Hesaplama maliyeti yüksektir ve çok fazla ağaç eğitildiğinde yavaş çalışabilir.

import pandas as pd 
from sklearn.model_selection import train_test_split  
from sklearn.ensemble import RandomForestClassifier #değişen kısım
from sklearn.metrics import accuracy_score, classification_report

# veri seti işlemleri
from sklearn.datasets import load_iris  
iris = load_iris()  
data = pd.DataFrame(iris.data, columns=iris.feature_names) 
data['species'] = iris.target 


print(data.head()) 

# Özellikleri ve hedef değişkeni ayıralım
X = data[iris.feature_names] 
y = data['species']  

# Veriyi eğitim ve test setlerine ayıralım
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)


# Random Forest sınıflandırıcıyı eğitelim
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
# Test seti üzerinde tahmin yapalım
y_pred = model.predict(X_test)  

# Sonuçları değerlendirelim
accuracy = accuracy_score(y_test, y_pred) 
print(f"Model Doğruluğu: {accuracy}")  
print(classification_report(y_test, y_pred)) 