# AdaBoost (Adaptive Boosting)
# Ne için kullanılır?: Basit modelleri (genellikle zayıf öğreniciler olan karar ağaçları) alır ve bu modelleri bir araya getirerek daha güçlü bir sınıflandırma modeli oluşturur. Her adımda hatalı tahmin yapan örneklere daha fazla ağırlık verilir.
# Avantajları: Kolay uygulanır ve çoğu problemde iyi sonuçlar verir.
# Dezavantajları: Gürültülü verilerde overfitting'e yatkındır.

import pandas as pd 
from sklearn.model_selection import train_test_split  
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import accuracy_score, classification_report

# veri seti işlemleri
from sklearn.datasets import load_iris  
iris = load_iris()  
data = pd.DataFrame(iris.data, columns=iris.feature_names) 
data['species'] = iris.target 


print(data.head()) 

# Özellikleri ve hedef değişkeni ayıralım
X = data[iris.feature_names] 
y = data['species']  

# Veriyi eğitim ve test setlerine ayıralım
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)


# AdaBoost (Adaptive Boosting) sınıflandırıcıyı eğitelim
model = AdaBoostClassifier(n_estimators=50, random_state=42)
model.fit(X_train, y_train)
# Test seti üzerinde tahmin yapalım
y_pred = model.predict(X_test)  

# Sonuçları değerlendirelim
accuracy = accuracy_score(y_test, y_pred) 
print(f"Model Doğruluğu: {accuracy}")  
print(classification_report(y_test, y_pred)) 