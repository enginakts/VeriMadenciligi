# Destek Vektör Makineleri (Support Vector Machines - SVM)
# Ne için kullanılır?: Sınıflandırma ve regresyon problemleri için kullanılır. Sınıfları ayıran en iyi ayrım çizgisini (veya hiper düzlemi) bulmaya çalışır.
# Avantajları: Küçük ve orta büyüklükteki veri setlerinde iyi sonuçlar verir. Doğrusal olmayan sınıflar için kernel hileleri ile çözüm sağlayabilir.
# Dezavantajları: Büyük veri setlerinde hesaplama maliyeti artabilir. Parametre ayarı (kernel seçimi, C değeri, vs.) hassas olabilir.
import pandas as pd 
from sklearn.model_selection import train_test_split  
from sklearn.svm import SVC #değişen kısım
from sklearn.metrics import accuracy_score, classification_report

# veri seti işlemleri
from sklearn.datasets import load_iris  
iris = load_iris()  
data = pd.DataFrame(iris.data, columns=iris.feature_names) 
data['species'] = iris.target 


print(data.head()) 

# Özellikleri ve hedef değişkeni ayıralım
X = data[iris.feature_names] 
y = data['species']  

# Veriyi eğitim ve test setlerine ayıralım
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)


# SVM sınıflandırıcıyı eğitelim
model = SVC(kernel = "linear")
model.fit(X_train, y_train)
# Test seti üzerinde tahmin yapalım
y_pred = model.predict(X_test)  

# Sonuçları değerlendirelim
accuracy = accuracy_score(y_test, y_pred) 
print(f"Model Doğruluğu: {accuracy}")  
print(classification_report(y_test, y_pred)) 